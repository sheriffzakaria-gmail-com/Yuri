﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    class Program
    {
        static void Main(string[] args)
        {
            string isNegative = "";
            try
            {
                Console.WriteLine("Enter the required amount which will be converted automatically to currency phrase");
                string amount = Console.ReadLine();
                amount = Convert.ToDouble(amount).ToString();

                if (amount.Contains("-"))
                {
                    isNegative = "Minus ";
                    amount = amount.Substring(1, amount.Length - 1);
                }
                if (amount == "0")
                {
                    Console.WriteLine("The amount in currency fomat is \nZero Only");
                }
                else
                {
                    Console.WriteLine("The amount in currency fomat is \n{0}", isNegative + Convert_Amount_With_Fraction_To_String(amount));
                }
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }  
        }
        private static String ones(String F_Amount)
        {
            int Amount = Convert.ToInt32(F_Amount);
            String name = "";
            switch (Amount)
            {

                case 1:
                    name = "One";
                    break;
                case 2:
                    name = "Two";
                    break;
                case 3:
                    name = "Three";
                    break;
                case 4:
                    name = "Four";
                    break;
                case 5:
                    name = "Five";
                    break;
                case 6:
                    name = "Six";
                    break;
                case 7:
                    name = "Seven";
                    break;
                case 8:
                    name = "Eight";
                    break;
                case 9:
                    name = "Nine";
                    break;
            }
            return name;
        }

        //i will use in the tens function the recursive concept (the function will call itself again from inside the function body)
        private static String tens(String F_Amount)
        {
            int Amount = Convert.ToInt32(F_Amount);
            String name = null;
            switch (Amount)
            {
                case 10:
                    name = "Ten";
                    break;
                case 11:
                    name = "Eleven";
                    break;
                case 12:
                    name = "Twelve";
                    break;
                case 13:
                    name = "Thirteen";
                    break;
                case 14:
                    name = "Fourteen";
                    break;
                case 15:
                    name = "Fifteen";
                    break;
                case 16:
                    name = "Sixteen";
                    break;
                case 17:
                    name = "Seventeen";
                    break;
                case 18:
                    name = "Eighteen";
                    break;
                case 19:
                    name = "Nineteen";
                    break;
                case 20:
                    name = "Twenty";
                    break;
                case 30:
                    name = "Thirty";
                    break;
                case 40:
                    name = "Fourty";
                    break;
                case 50:
                    name = "Fifty";
                    break;
                case 60:
                    name = "Sixty";
                    break;
                case 70:
                    name = "Seventy";
                    break;
                case 80:
                    name = "Eighty";
                    break;
                case 90:
                    name = "Ninety";
                    break;
                default:
                    if (Amount > 0)
                    {
                        //recursive concept for tens function
                        //here if the number is 35 then i will cut the 3 and concatenate to it 0
                       //as result and after applying the recursive concept on tens function
                       //i will get "Thirty" string and i will cut the second number which is 5 and pass it
                       //to ones function which get back us with "Five" string 
                      //at the end and after applying the concatenation we will gain the string "Thirty Five" 
                        name = tens(F_Amount.Substring(0, 1) + "0") + " " + ones(F_Amount.Substring(1));
                    }
                    break;
            }
            return name;
        }

        // here also in this function i will use the recursive concept 
        //here in this function i will debend on the lenght of the amount to determine the required range
        private static String Convert_The_Number_without_Fraction(String F_Amount)
        {
            string phrase = "";
           
                bool beginWithZero = false;//tests for 0XX    
                bool Done = false;   
                double Amount = (Convert.ToDouble(F_Amount));
                 
                if (Amount > 0)
                {//test for zero or digit zero in a nuemric    
                    beginWithZero = F_Amount.StartsWith("0");

                    int amountLenght = F_Amount.Length;
                    int pos = 0;    
                    String Range = "";//range name:hundres,thousand,...    
                  
                    switch (amountLenght)
                    {
                        case 1://ones' range    

                            phrase = ones(F_Amount);
                            Done = true;
                            break;
                        case 2://tens' range    
                            phrase = tens(F_Amount);
                            Done = true;
                            break;
                        case 3://hundreds' range    
                            pos = (amountLenght % 3) + 1;
                            Range = " Hundred and ";
                            break;
                        case 4://thousands' range    
                        case 5:
                        case 6:
                            pos = (amountLenght % 4) + 1;
                            Range = " Thousand, ";
                            break;
                        case 7://millions' range    
                        case 8:
                        case 9:
                            pos = (amountLenght % 7) + 1;
                            Range = " Million, ";
                            break;
                        //Billions's range (the maximum here is Nine Hundred and Ninety Nine Billion, DOLLARS AND Ninety Nine CENTS) 
                        case 10:    
                        case 11:
                        case 12:
                            pos = (amountLenght % 10) + 1;
                            Range = " Billion, ";
                            break;

                        default:
                            Done = true;
                            break;
                    }
                    if (!Done)// if converting still not done for examle in hundreds - thousands - millions -  Billions ranges 
                    {    
                        if (F_Amount.Substring(0, pos) != "0" && F_Amount.Substring(pos) != "0"
                            && Convert.ToInt32(F_Amount.Substring(0, pos)) != 0)
                        {  
                                //i apply recursive concept
                                phrase = Convert_The_Number_without_Fraction(F_Amount.Substring(0, pos)) + Range +
                                         Convert_The_Number_without_Fraction(F_Amount.Substring(pos));
                            
                        }
                        else
                        {
                            //i apply recursive concept
                            phrase = Convert_The_Number_without_Fraction(F_Amount.Substring(0, pos)) +
                                     Convert_The_Number_without_Fraction(F_Amount.Substring(pos));
                        }

                    }
                    //ignore digit ranges names    
                    if (phrase.Trim().Equals(Range.Trim())) phrase = "";
                }
           
           
            return phrase.Trim();
        }

        private static String Convert_Amount_With_Fraction_To_String(String F_Amount)
        {
            String result = "", amountWithoutFraction = "", points = "", andStr = "", pointStr = "";
            String currencyType = " DOLLARS", fractionType = " CENTS ", endStr = "ONLY";
            
                int fractionPlace = F_Amount.IndexOf(".");
                if (fractionPlace > 0)
                {
                    amountWithoutFraction = F_Amount.Substring(0, fractionPlace);

                    points = F_Amount.Substring(fractionPlace + 1, 2);
                    if (Convert.ToInt32(points) > 0)
                    {
                        andStr = "AND";// just to separate whole numbers from points/cents    
                        endStr = fractionType  + endStr;
                        pointStr = Handle_Fraction_Part(points);
                    }
                }
                result = String.Format("{0} {1}{2}{3}",
                      Convert_The_Number_without_Fraction(amountWithoutFraction).Trim() + currencyType
                      , andStr, pointStr, endStr);
            
            return result;
        }

        private static String Handle_Fraction_Part(String F_fraction)
        {
            F_fraction = " " + tens(F_fraction);
            return F_fraction; 
        }


    }//program
}
